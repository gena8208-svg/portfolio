<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/boot.php';
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}
try {
    $pdo = pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $clientId = $_POST['id'];
    $nal = is_numeric($_POST['nalminus']) ? -abs($_POST['nalminus']) : 0;
    $kassa = is_numeric($_POST['kassaminus']) ? -abs($_POST['kassaminus']) : 0;
    $ekv = is_numeric($_POST['ekvminus']) ? -abs($_POST['ekvminus']) : 0;
    $transfer = is_numeric($_POST['transferminus']) ? -abs($_POST['transferminus']) : 0;
    $payment_accountminus = is_numeric($_POST['payment_accountminus']) ? -abs($_POST['payment_accountminus']) : 0;
    $comment = $_POST['commentminus'];
    $office = $_POST['office'];


    $pdo->beginTransaction();


    $stmt = $pdo->prepare("SELECT name, site_id, dolg FROM users WHERE id = :id");
    $stmt->bindParam(':id', $clientId);
    $stmt->execute();
    $clientData = $stmt->fetch();
    $dolg = $clientData['dolg'];

    if (!$clientData) {
        $pdo->rollBack();
        echo json_encode(['status' => 'error', 'message' => 'Клиент не найден.']);
        return;
    }

    $manager_name = $_SESSION['username'];
    if (empty($nal)) $nal = 0;
    if (empty($kassa)) $kassa = 0;
    if (empty($ekv)) $ekv = 0;
    if (empty($transfer)) $transfer = 0;
    if (empty($payment_accountminus)) $payment_accountminus = 0;
    $shipment = 0;
    // сохранить данные в таблицу kassa
    $stmt1 = $pdo->prepare("INSERT INTO kassa (date, name, site_id, user_id, cash, kassa, acquiring, transfer, payment_account, shipment, comment, office, manager_name) VALUES (:date, :name, :site_id, :user_id, :cash, :kassa, :acquiring, :transfer, :payment_account, :shipment, :comment, :office, :manager_name)");
    date_default_timezone_set('Europe/Moscow');
    $todayDate = date('Y-m-d H:i:s');
    $stmt1->bindParam(':date', $todayDate);
    $stmt1->bindParam(':name', $clientData['name']);
    $stmt1->bindParam(':site_id', $clientData['site_id']);
    $stmt1->bindParam(':user_id', $clientId);
    $stmt1->bindParam(':cash', $nal);
    $stmt1->bindParam(':kassa', $kassa);
    $stmt1->bindParam(':acquiring', $ekv);
    $stmt1->bindParam(':transfer', $transfer);
    $stmt1->bindParam(':payment_account', $payment_accountminus);
    $stmt1->bindParam(':shipment', $shipment);
    $stmt1->bindParam(':comment', $comment);
    $stmt1->bindParam(':office', $office);
    $stmt1->bindParam(':manager_name', $manager_name);
    $stmt1->execute();
    $logMessage = "";
    $logMessage = "[" . $todayDate . "] Операция: Внесение данных в таблицу kassa\n";
    $logMessage .= "clientId: " . $clientId . ", nal: " . $nal . ", kassa: " . $kassa . ", ekv: " . $ekv . ", transfer: " . $transfer . ", payment_account: " . $payment_accountminus . ", comment: " . $comment . ", office: " . $office . ", manager_name: " . $manager_name . "\n";
    error_log($logMessage, 3, 'logs/spisanie_v_kasse_adm.log');
    $sumall = (int)$nal + (int)$kassa + (int)$ekv + (int)$transfer + (int)$payment_accountminus;
    $dolg = (int)$clientData['dolg'] + $sumall;
    $stmt2 = $pdo->prepare("UPDATE users SET dolg = :dolg WHERE id = :id");
    $stmt2->bindParam(':dolg', $dolg);
    $stmt2->bindParam(':id', $clientId);
    $stmt2->execute();
    $logMessage = "";
    $logMessage = "[" . $todayDate . "] Операция: Обновление баланса клиента в таблице users\n";
    $logMessage .= "clientId: " . $clientId . ", dolg: " . $dolg . "\n";
    error_log($logMessage, 3, 'logs/spisanie_v_kasse_adm.log');
    $pdo->commit();
    echo json_encode(['status' => 'success']);
} catch (PDOException $e) {
    $pdo->rollBack();
    echo json_encode(['status' => 'error', 'message' => 'Ошибка: ' . $e->getMessage()]);
}
