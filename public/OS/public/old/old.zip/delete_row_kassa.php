<?php
header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/boot.php';
if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}
try {
    $pdo = pdo();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $id = $_POST['id'];
    $clientId = $_POST['site_id'];
    $oldsum = $_POST['oldsum'];

    $pdo->beginTransaction();

    // Получить текущий долг клиента
    $stmt = $pdo->prepare("SELECT dolg FROM users WHERE site_id = :site_id");
    $stmt->bindParam(':site_id', $clientId);
    $stmt->execute();
    $clientData = $stmt->fetch();
    $dolg = $clientData['dolg'];

    // Удалить запись из таблицы kassa по ID строки
    $stmt1 = $pdo->prepare("DELETE FROM kassa WHERE id = :id");
    $stmt1->bindParam(':id', $id);
    $stmt1->execute();

    // Обновить долг клиента
    $dolg = $dolg - (int)$oldsum;
    $stmt2 = $pdo->prepare("UPDATE users SET dolg = :dolg WHERE site_id = :site_id");
    $stmt2->bindParam(':dolg', $dolg);
    $stmt2->bindParam(':site_id', $clientId);
    $stmt2->execute();

    $pdo->commit();
    echo json_encode(['status' => 'success']);
} catch (PDOException $e) {
    $pdo->rollBack();
    echo json_encode(['status' => 'error', 'message' => 'Ошибка: ' . $e->getMessage()]);
}
